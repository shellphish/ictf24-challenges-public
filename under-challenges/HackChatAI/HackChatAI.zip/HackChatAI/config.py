# Initialize the SQLite database
DATABASE = 'cookies.db'
